# Stars Zoro Bot

Telegram-бот на **aiogram 3.x**, который сам собирает курсы и новости (Stars, подарки/NFT, GRAM, TON, Fragment) и публикует посты в канал по расписанию.

## Структура

```
stars_zoro_bot/
├── main.py                  # точка входа
├── requirements.txt
├── .env.example             # скопируйте в .env
├── README.md
├── data/                    # создаётся сам: state.json (антидубли, лог, шаблоны), bot.log
└── bot/
    ├── config.py            # конфиг из .env
    ├── scheduler.py         # автопостинг по SCHEDULE
    ├── handlers/admin.py    # /status, /post, /say, /addtemplate ...
    ├── services/
    │   ├── prices.py        # CoinGecko
    │   ├── news.py          # Google News RSS + свои RSS
    │   ├── generator.py     # тексты постов и шаблоны
    │   ├── publisher.py     # публикация, ретраи, фолбэки
    │   └── storage.py       # JSON-хранилище
    └── utils/               # logger, formatting
```

## Запуск

1. Python 3.10+.
2. Создайте бота в @BotFather, добавьте его **администратором канала** (право публиковать сообщения).
3. Установка:
   ```bash
   python -m venv .venv
   source .venv/bin/activate        # Windows: .venv\Scripts\activate
   pip install -r requirements.txt
   cp .env.example .env             # и заполните
   python main.py
   ```
4. Напишите боту `/start` — если ваш ID в `ADMIN_IDS`, увидите список команд.

## Расписание

В `.env`: `SCHEDULE=10:00:price,13:00:news,17:00:promo,20:00:news`

- формат `ЧЧ:ММ:тип`, часовой пояс — `TIMEZONE`;
- `price` — курсы, `news` — свежая новость, `promo` — шаблонный продающий пост, `auto` — новость, а если нет свежей — промо;
- если нужный тип недоступен (API лёг, новых новостей нет), бот публикует промо-пост вместо пропуска.

## Команды администратора

| Команда | Что делает |
|---|---|
| `/status` | аптайм, расписание, следующий пост, последние 5 действий |
| `/post [price\|news\|promo\|auto]` | опубликовать пост сейчас |
| `/say текст` | отправить в канал свой текст (HTML разрешён) |
| `/templates`, `/addtemplate`, `/deltemplate` | свои шаблоны промо-постов |

В шаблонах можно использовать `{cta}` (CTA_TEXT) и `{tags}` (HASHTAGS).
Базовые шаблоны лежат в `bot/services/generator.py` (`DEFAULT_TEMPLATES`).

## Защита от дублей

Каждая опубликованная новость запоминается по хэшу нормализованного заголовка (без источника и пунктуации), последние 1000 штук хранятся в `data/state.json`. Одна и та же новость из разных лент не выйдет дважды.

## Важно проверить

- **GRAM на CoinGecko.** Я не могу гарантировать, что у GRAM есть листинг и какой у него API id. Откройте страницу монеты на coingecko.com, найдите «API id» и впишите в `COINS` (`GRAM=<id>`). Если монеты нет, бот просто пропустит её и покажет только TON — ошибки не будет.
- **Курсы и юридическое.** Посты с курсами — информационные, не инвестиционный совет; при желании добавьте дисклеймер в `CTA_TEXT` или шаблоны.
- **Источники новостей.** По умолчанию используется публичный RSS Google News (заголовок + ссылка, без копирования текста статей). Свои ленты добавляйте через `EXTRA_RSS`; страницы не парсятся, так что robots.txt не затрагивается. Лимит CoinGecko для публичного API небольшой, но 3–5 запросов в день его не превышают.
- В пост попадает только заголовок и ссылка на источник — полные тексты чужих статей бот не копирует.

## Запуск как сервис (Linux, systemd)

```ini
[Unit]
Description=Stars Zoro Bot
After=network-online.target

[Service]
WorkingDirectory=/opt/stars_zoro_bot
ExecStart=/opt/stars_zoro_bot/.venv/bin/python main.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```
